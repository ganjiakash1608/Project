package com.cg.controller;

import java.util.List;

import javax.validation.Valid;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Admin;
import com.cg.entity.Employee;
import com.cg.service.AdminService;
import com.cg.service.EmployeeService;

@CrossOrigin("http://localhost:4200")
@RestController
public class EmployeeAttendanceController {

	@Autowired
	AdminService adminservice;

	@Autowired
	EmployeeService employeeservice;

	@GetMapping(path = "/getAdmin", produces = "application/json")
	public List<Admin> getAdminList() {
		return (List<Admin>) adminservice.getAdminList();
	}
	

	@GetMapping(path = "/getEmployee", produces = "application/json")
	public List<Employee> getEmployeeList() {
		return (List<Employee>) employeeservice.getEmployeeList();
	}

	@PostMapping(path = "/addEmployee", consumes = "application/json", produces = "application/json")
	public Employee addEmployee(@RequestBody Employee e) {
		return employeeservice.addEmployee(e);
	}

	@PutMapping(path = "/updateEmployee/{id}", consumes = "application/json")
	public Employee updateEmployee(@PathVariable("id") int id, @RequestBody Employee e) {
		return employeeservice.updateEmployee(id, e);

	}
	
	@DeleteMapping(path = "/deleteEmployee/{id}")
	public String deleteEmployee(@PathVariable("id") int id) {
		return employeeservice.deleteEmployee(id);

	}	
	
	@GetMapping(path="/getEmployeeById/{id}",produces = "application/json")
	public Employee getEmployeeById(@PathVariable("id") int id) {
		return employeeservice.getEmployeeById(id);		
	}
}
