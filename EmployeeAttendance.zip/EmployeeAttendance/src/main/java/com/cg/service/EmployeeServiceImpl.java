package com.cg.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

@Service
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	EmployeeRepo employeerepo;

	@Override
	public Employee addEmployee(Employee e) {
		e.setEmployeePassword(e.getFirstName()+e.getLastName()+"@123");
		return employeerepo.save(e);
	}

	@Override
	public List<Employee> getEmployeeList() {

		return (List<Employee>) employeerepo.findAll();
	}

	@Override
	public Employee updateEmployee(int id, Employee e) {
		e.setId(id);
		return employeerepo.save(e);
	}

	@Override
	public String deleteEmployee(int id) {
		Employee e1=employeerepo.findById(id).get();
		employeerepo.delete(e1);
		return ("Deleted");
	}

	@Override
	public Employee getEmployeeById(int id) {
		Employee e1=employeerepo.findById(id).get();
		return e1;
	}

}
