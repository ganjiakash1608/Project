import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { FormControl, Validators } from '@angular/forms';
import { LoginServiceService } from "../login-service.service";
import { Employee } from '../model/employeeDetails';

@Component({
  selector: 'app-employee-login',
  templateUrl: './employee-login.component.html',
  styleUrls: ['./employee-login.component.css']
})
export class EmployeeLoginComponent implements OnInit {
  logincheck: Employee[];
  login: Employee;
  employeecheck: Employee;
  employeeEmailId: any;
  employeePassword: any;


  constructor(private router: Router, private service: LoginServiceService) { 
    this.login = new Employee();
    this.employeeEmailId = this.login.employeeEmailId;
    this.employeePassword = this.login.employeePassword;
  }

  ngOnInit() {
  }
  getEmployee() {

    this.service.getEmployee().subscribe(res => {
      this.logincheck = res;
      var loginSuccesful = false;
      this.logincheck.forEach(element => {
        var employee = element;
        if(employee.employeeEmailId===this.login.employeeEmailId && employee.employeePassword===this.login.employeePassword){
          loginSuccesful = true;
        } 
      });
      
      if(loginSuccesful){
        alert("Login successful");
        this.router.navigate(['/employee']);
      }else{
        alert("Invalid details");
      }
    })



  }
}
